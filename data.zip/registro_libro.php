<?php
$Titulo_libro=$_GET["Titulo_libro"];
$Autor_libro=$_GET["Autor_libro"];
$Cantidad_libro=$_GET["Cantidad_libro"];
$Url_libro=$_GET["Url_libro"];
$Imagen_libro=$_GET["Imagen_libro"];
$Descripcion_libro=$_GET["Descripcion_libro"];


$cont=0;
include("conexion.php");

$q=mysqli_query($conexion,"INSERT INTO libros(_id, Titulo_libro, Autor_libro, Cantidad_libro, Url_libro, Imagen_libro, Descripcion_libro) VALUES (NULL,'$Titulo_libro',
 '$Autor_libro', '$Cantidad_libro', '$Url_libro', '$Imagen_libro', '$Descripcion_libro')");

if($q){
    echo "Registro insertado exitoso";
}
else{
    echo "Fallo en el registro";
}
