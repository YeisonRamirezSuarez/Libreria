<?php
$id = $_GET["id"];
$Titulo_libro=$_GET["Titulo_libro"];
$Autor_libro=$_GET["Autor_libro"];
$Cantidad_libro=$_GET["Cantidad_libro"];
$Url_libro=$_GET["Url_libro"];
$Imagen_libro=$_GET["Imagen_libro"];
$Descripcion_libro=$_GET["Descripcion_libro"];


$cont=0;
include("conexion.php");

// $q=mysqli_query($c,"UPDATE libros SET(_id, Titulo_libro, Autor_libro, Cantidad_libro, Url_libro, Imagen_libro, Descripcion_libro) VALUES ('NULL','$Titulo_libro',
//  '$Autor_libro', '$Cantidad_libro', '$Url_libro', '$Imagen_libro', '$Descripcion_libro')");

$q=mysqli_query($conexion,"UPDATE libros_prestados SET Titulo_libro_Prestado = '$Titulo_libro', Autor_libro_Prestado ='$Autor_libro',
Url_libro_Prestado ='$Url_libro', Imagen_libro_Prestado = '$Imagen_libro', Descripcion_libro_Prestado = '$Descripcion_libro' WHERE _id_Libro = '$id'");

if($q){
    echo "correcto";
}
else{
    echo "Fallo";
}
