<?php
include 'conexion.php';

$sentencia=$conexion->prepare( "SELECT * FROM libros");

$sentencia->execute();

$resultado = $sentencia->get_result();


/*echo $resultado;
for($i=0; $i<$resultado->num_rows; $i++){
    
     if ($fila = $resultado->fetch_assoc()) {
     echo json_encode($fila,JSON_UNESCAPED_UNICODE); 
    
    
 }else{
     echo "Fail";
}
 }

while ($fila = $resultado->fetch_assoc()) {
    echo json_encode($fila,JSON_UNESCAPED_UNICODE);
}*/

$fila = array(
    "libros" => []
);
$cont = 0;

for($i=0; $i< $resultado->num_rows; $i++){
    $fila["libros"][$cont] = $resultado -> fetch_assoc();
    $cont++;
}
echo json_encode($fila);



$sentencia->close();
$conexion->close();  
?>