<?php


$nombre=$_POST["nombre"];
$apellido=$_POST["apellido"];
$direccion=$_POST["direccion"];
$telefono=$_POST["telefono"];
$correo=$_POST["correo"];
$sexo=$_POST["sexo"];
$fecha=$_POST["fecha"];

$cont=0;
include("conexion.php");

$q=mysqli_query($conexion,"INSERT INTO usuarios(id, nombre, apellido, direccion, telefono, correo, sexo, fecha) VALUES ('NULL','$nombre', '$apellido', '$direccion', '$telefono', '$correo', '$sexo', '$fecha')");

if($q){
    echo "Registro insertado exitoso";
}
else{
    echo "Fallo en el registro";
}
?>