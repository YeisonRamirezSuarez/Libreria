<?php
//login

$correo=$_POST["CorreoElectronico_Administrador"];
$contrasena=$_POST["Contrasena_Administrador"];


include("cn.php");

$setencia = $c->prepare("SELECT * FROM administrador WHERE correo =? AND contrasena =?");
$setencia->bind_param('ss', $correo, $contrasena);
$setencia->execute();

$resultado = $setencia->get_result();
if($fila = $resultado->fetch_assoc()){
    echo json_encode($fila, JSON_UNESCAPED_UNICODE);
}
$setencia->close();
$c->close();

?>