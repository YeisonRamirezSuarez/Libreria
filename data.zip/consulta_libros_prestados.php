<?php
include 'conexion.php';
if(isset($_GET['id'])){

    //$libro_id=$_POST['id'];
    $id=$_GET['id'];
    $sentencia=$conexion->prepare("SELECT Nombre_Usuario_Prestamo_libro, Correo_Prestamo_libro, Telefono_Usuario_Prestamo_libro FROM libros_prestados WHERE _id_Libro = '$id'");
    $sentencia->execute();
    $resultado = $sentencia->get_result();

    
    $fila = array(

        "libros_prestados" => [

        ]

        
    );
    $cont = 0;
    
    for($i=0; $i< $resultado->num_rows; $i++){
        $fila["libros_prestados"][$cont] = $resultado -> fetch_assoc();
        $cont++;
    }
    echo json_encode($fila);

    
    $sentencia->close();
    $conexion->close();  
}
else{
    echo "No hay nada dentro de los parametros";
    }
?>