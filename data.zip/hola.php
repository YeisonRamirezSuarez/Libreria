<?php

echo "Hola soy gay";