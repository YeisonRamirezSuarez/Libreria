<?php
include 'conexion.php';

if(isset($_POST['usuario']) && isset($_POST['password'])){

    $usu_usuario=$_POST['usuario'];
    $usu_password=$_POST['password'];
    
$sentencia=$conexion->prepare("SELECT Rol_Usuario FROM usuario WHERE Correo_Electronico=? AND Contrasena_Usuario=?");
    $sentencia->bind_param('ss',$usu_usuario,$usu_password);
    $sentencia->execute();
    $resultado = $sentencia->get_result();

    if ($fila = $resultado->fetch_assoc()) {
        //echo json_encode($fila,JSON_UNESCAPED_UNICODE); 
        echo $fila["Rol_Usuario"];
        $sentencia->close();
        $conexion->close();   
        
    }else{
        echo "Fail";
    }

}else{
    echo "No hay nada dentro de los parametros";
}

?>