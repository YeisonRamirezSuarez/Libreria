<?php
include 'conexion.php';

if(isset($_POST['Correo_Electronico'])){

    $usu_correo=$_GET['Correo_Electronico'];
    $sentencia=$conexion->prepare("SELECT * FROM usuario WHERE Correo_Electronico=?");
    $sentencia->bind_param('s',$usu_correo);
    $sentencia->execute();
    $resultado = $sentencia->get_result();

    if ($fila = $resultado->fetch_assoc()) {
       // echo json_encode($fila,JSON_UNESCAPED_UNICODE); 
        echo $fila["Rol_Usuario"];
        $sentencia->close();
        $conexion->close();   
        
    }else{
        echo "Fail";
    }

}else{

    echo "No hay nada dentro de los parametros";
}




    // $sentencia=$conexion->prepare("SELECT * FROM usuario WHERE Correo_Electronico = ?" );
    // $sentencia->execute();
    // $resultado = $sentencia->get_result();
    
    // // for($i=0; $i<$resultado->num_rows; $i++){
    // //     if ($fila = $resultado->fetch_assoc()) {
    // //     echo json_encode($fila,JSON_UNESCAPED_UNICODE); 
        
        
    // // }else{
    // //     echo "Fail";
    // // }

    // // }

    // //while ($fila = $resultado->fetch_assoc()) {
    // //    echo json_encode($fila,JSON_UNESCAPED_UNICODE);
    // //}
    // $fila = array(

    //     "libros" => [

    //     ]

        
    // );
    // $cont = 0;
    
    // for($i=0; $i< $resultado->num_rows; $i++){
    //     $fila["libros"][$cont] = $resultado -> fetch_assoc();
    //     $cont++;
    // }
    // echo json_encode($fila);

    
    
  
?>