<?php
include 'conexion.php';
//if(isset($_GET['id'])){

    //$libro_id=$_GET['id'];
   // $id=$_GET['id'];
    $sentencia=$conexion->prepare("SELECT * FROM libros_prestados GROUP BY _id_Libro");
    $sentencia->execute();
    $resultado = $sentencia->get_result();

    
    $fila = array(

        "libros_prestados" => [

        ]

        
    );
    $cont = 0;
    
    for($i=0; $i< $resultado->num_rows; $i++){
        $fila["libros_prestados"][$cont] = $resultado -> fetch_assoc();
        $cont++;
    }
    echo json_encode($fila);

    
    $sentencia->close();
    $conexion->close();  
    
//}else{

 //   echo "No hay nada dentro de los parametros";
 //   }
?>