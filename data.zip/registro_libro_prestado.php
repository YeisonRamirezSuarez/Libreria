<?php
$id=$_GET["id"];
$Titulo_libro=$_GET["Titulo_libro"];
$Autor_libro=$_GET["Autor_libro"];
//$Cantidad_libro=$_GET["Cantidad_libro"];
$Url_libro=$_GET["Url_libro"];
$Imagen_libro=$_GET["Imagen_libro"];
$Descripcion_libro=$_GET["Descripcion_libro"];
$Fecha_Prestamo_libro=$_GET["Fecha_Prestamo_libro"];
$Correo_Prestamo_libro=$_GET["Correo_Prestamo_libro"];
$Nombre_Usuario_Prestamo_libro=$_GET["Nombre_Usuario_Prestamo_libro"];
$Telefono_Usuario_Prestamo_libro=$_GET["Telefono_Usuario_Prestamo_libro"];

$cont=0;
include("conexion.php");



$q=mysqli_query($conexion,"INSERT INTO `libros_prestados` (`_id`, `_id_Libro`, `Titulo_libro_Prestado`, `Autor_libro_Prestado`, `Url_libro_Prestado`, `Imagen_libro_Prestado`, `Descripcion_libro_Prestado`, `Fecha_Prestamo_libro`, `Correo_Prestamo_libro`, `Nombre_Usuario_Prestamo_libro`, `Telefono_Usuario_Prestamo_libro`) VALUES (NULL, '$id', '$Titulo_libro', '$Autor_libro', '$Url_libro', '$Imagen_libro', '$Descripcion_libro', '$Fecha_Prestamo_libro', '$Correo_Prestamo_libro', '$Nombre_Usuario_Prestamo_libro', '$Telefono_Usuario_Prestamo_libro')");


if($q){
    echo "Libro prestado";
}
else{
    echo "Fallo el prestado";
}
